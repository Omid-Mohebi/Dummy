#define F_CPU 8000000UL

#include <mega32.h>
#include <delay.h>

#define BTN_LEFT    PINB.0
#define BTN_RIGHT   PINB.2
#define BTN_OK      PINB.1

#define LCD_RS      PORTC.0
#define LCD_RW      PORTC.1
#define LCD_E       PORTC.2
#define LCD_DATA    PORTC

volatile unsigned int adc_result = 0;
volatile unsigned char adc_channel = 0;
volatile unsigned char adc_ready = 0;
unsigned int temperature_readings[8] = {0,0,0,0,0,0,0,0};
unsigned char current_sensor = 0;
unsigned char display_update_flag = 1;
unsigned long int millis_ticks = 0;
unsigned long int last_adc_time = 0;
unsigned long int last_display_time = 0;

interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
    millis_ticks++;
}

interrupt [ADC_INT] void adc_complete_isr(void)
{
    adc_result = ADCW;
    adc_ready = 1;
}

void timer0_init(void)
{
    TCCR0 = (1 << WGM01);
    OCR0 = 124;
    TIMSK |= (1 << OCIE0);
    TCCR0 |= (1 << CS01) | (1 << CS00);
    #asm("sei");
}

void adc_init(void)
{
    ADMUX = (1 << REFS1) | (1 << REFS0); 
    
    ADCSRA = (1 << ADEN) | (1 << ADIE) | (1 << ADPS2) | (1 << ADPS1);
}

void adc_start_conversion(unsigned char channel)
{
    if (channel > 7) return;
    
    ADMUX = (ADMUX & 0xF8) | (channel & 0x07);
    
    adc_channel = channel;
    
    ADCSRA |= (1 << ADSC);
    adc_ready = 0;
}

void lcd_pulse_enable(void)
{
    LCD_E = 1;
    delay_us(1);
    LCD_E = 0;
    delay_us(1);
}

void lcd_write_nibble(unsigned char data)
{
    LCD_DATA = (LCD_DATA & 0x0F) | (data & 0xF0);
    lcd_pulse_enable();
}

void lcd_write_byte(unsigned char data)
{
    lcd_write_nibble(data);
    lcd_write_nibble(data << 4);
    delay_us(50);
}

void lcd_command(unsigned char cmd)
{
    LCD_RS = 0;
    LCD_RW = 0;
    lcd_write_byte(cmd);
    delay_ms(2);
}

void lcd_data(unsigned char data)
{
    LCD_RS = 1;
    LCD_RW = 0;
    lcd_write_byte(data);
    delay_us(50);
}

void lcd_init(void)
{
    delay_ms(20);
    
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_E = 0;
    
    lcd_write_nibble(0x30);
    delay_ms(5);
    lcd_write_nibble(0x30);
    delay_us(150);
    lcd_write_nibble(0x30);
    delay_us(150);
    lcd_write_nibble(0x20);
    delay_us(150);
    
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    lcd_command(0x01);
    delay_ms(2);
}

void lcd_goto(unsigned char row, unsigned char col)
{
    unsigned char address;
    if (row == 0)
        address = 0x80 + col;
    else
        address = 0xC0 + col;
    lcd_command(address);
}

void lcd_puts(char *str)
{
    while (*str)
    {
        lcd_data(*str);
        str++;
    }
}

void lcd_putchar(char c)
{
    lcd_data(c);
}

unsigned int convert_to_temperature(unsigned int adc_value)
{
    return (unsigned int)(((unsigned long)adc_value * 10UL) / 4UL);
}

void display_temperature(void)
{
    unsigned int temp_tenths;
    unsigned char temp_whole, temp_decimal;
    char temp_str[8];
    unsigned char i;
    
    lcd_command(0x01);
    delay_ms(2);
    
    lcd_goto(0, 0);
    lcd_puts("Sensor ");
    lcd_putchar('0' + current_sensor);
    lcd_puts(" (LM35)");
    
    lcd_goto(1, 0);
    temp_tenths = temperature_readings[current_sensor];
    temp_whole = temp_tenths / 10;
    temp_decimal = temp_tenths % 10;
    
    lcd_puts("Temp: ");
    
    if (temp_whole >= 100)
    {
        lcd_putchar('0' + (temp_whole / 100));
        temp_whole %= 100;
    }
    if (temp_whole >= 10 || temperature_readings[current_sensor] >= 100)
    {
        lcd_putchar('0' + (temp_whole / 10));
        temp_whole %= 10;
    }
    lcd_putchar('0' + temp_whole);
    lcd_putchar('.');
    lcd_putchar('0' + temp_decimal);
    lcd_putchar('C');
}

void handle_buttons(void)
{
    static unsigned long int last_button_time = 0;
    const unsigned char DEBOUNCE_DELAY = 150;
    
    if (millis_ticks - last_button_time < DEBOUNCE_DELAY)
        return;
    
    if (BTN_LEFT == 1)
    {
        delay_ms(50);
        while(BTN_LEFT == 1);
        
        if (current_sensor > 0)
        {
            current_sensor--;
        }
        else
        {
            current_sensor = 7;
        }
        
        display_update_flag = 1;
        last_button_time = millis_ticks;
    }
    else if (BTN_RIGHT == 1)
    {
        delay_ms(50);
        while(BTN_RIGHT == 1);
        
        if (current_sensor < 7)
        {
            current_sensor++;
        }
        else
        {
            current_sensor = 0;
        }
        
        display_update_flag = 1;
        last_button_time = millis_ticks;
    }
    else if (BTN_OK == 1)
    {
        delay_ms(50);
        while(BTN_OK == 1);
        
        adc_start_conversion(current_sensor);
        display_update_flag = 1;
        last_button_time = millis_ticks;
    }
}

void update_sensor_readings(void)
{
    static unsigned char reading_sensor = 0;
    static unsigned char adc_busy = 0;
    const unsigned int ADC_INTERVAL = 100;
    
    if (millis_ticks - last_adc_time >= ADC_INTERVAL)
    {
        if (adc_ready && adc_busy)
        {
            temperature_readings[adc_channel] = convert_to_temperature(adc_result);
            adc_busy = 0;
            adc_ready = 0;
            
            reading_sensor++;
            if (reading_sensor >= 8)
            {
                reading_sensor = 0;
            }
        }
        
        if (!adc_busy)
        {
            adc_start_conversion(reading_sensor);
            adc_busy = 1;
            last_adc_time = millis_ticks;
        }
    }
    
    if (adc_ready && !adc_busy)
    {
        temperature_readings[adc_channel] = convert_to_temperature(adc_result);
        adc_ready = 0;
        display_update_flag = 1;
    }
}

void update_display(void)
{
    const unsigned int DISPLAY_INTERVAL = 500;
    
    if (display_update_flag || (millis_ticks - last_display_time >= DISPLAY_INTERVAL))
    {
        display_temperature();
        display_update_flag = 0;
        last_display_time = millis_ticks;
    }
}

void main(void)
{
    unsigned char i;
    
    DDRA = 0x00;
    DDRB = 0x00;
    DDRC = 0xFF;
    DDRD = 0x00;
    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;
    
    for (i = 0; i < 8; i++)
    {
        temperature_readings[i] = 0;
    }
    current_sensor = 0;
    
    timer0_init();
    adc_init();
    delay_ms(100);
    lcd_init();
    
    lcd_goto(0, 0);
    lcd_puts("Temperature");
    lcd_goto(1, 0);
    lcd_puts("Monitor Ready");
    delay_ms(1000);
    
    adc_start_conversion(0);
    display_update_flag = 1;
    
    while (1)
    {
        handle_buttons();
        update_sensor_readings();
        update_display();
    }
}