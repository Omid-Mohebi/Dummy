#define F_CPU 8000000UL
#include <mega32.h>

unsigned char portA_state = 0x00;
unsigned char portB_pattern = 0x80;
unsigned char portC_pattern = 0x01;
unsigned char portD_led = 0;
unsigned char portD_state = 0x00;
unsigned char portD_direction = 1;

unsigned int timer_A = 0;
unsigned int timer_B = 0;
unsigned int timer_C = 0;
unsigned int timer_D = 0;

void init_ports(void) {
    DDRA = 0xFF;
    DDRB = 0xFF;
    DDRC = 0xFF;
    DDRD = 0xFF;
    
    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;
}

void update_portA_pattern(void) {
    portA_state = portA_state ^ 0xFF;
    PORTA = portA_state;
}

void update_portB_pattern(void) {
    PORTB = portB_pattern;
    portB_pattern = portB_pattern >> 1;
    if (portB_pattern == 0) {
        portB_pattern = 0x80;
    }
}

void update_portC_pattern(void) {
    PORTC = portC_pattern;
    portC_pattern = portC_pattern << 1;
    if (portC_pattern == 0) {
        portC_pattern = 0x01;
    }
}

void update_portD_pattern(void) {
    if (portD_direction == 1) {
        portD_state = portD_state | (1 << portD_led);
        PORTD = portD_state;
        portD_led++;
        if (portD_led >= 8) {
            portD_led = 0;
            portD_direction = 0;
        }
    } else {
        portD_state = portD_state & ~(1 << portD_led);
        PORTD = portD_state;
        portD_led++;
        if (portD_led >= 8) {
            portD_led = 0;
            portD_direction = 1;
        }
    }
}

void main(void) {
    volatile unsigned int delay_counter;
    
    init_ports();
    
    while (1) {
        if (timer_A >= 310) {
            update_portA_pattern();
            timer_A = 0;
        }
        
        if (timer_B >= 45) {
            update_portB_pattern();
            timer_B = 0;
        }
        
        if (timer_C >= 260) {
            update_portC_pattern();
            timer_C = 0;
        }
        
        if (timer_D >= 110) {
            update_portD_pattern();
            timer_D = 0;
        }
        
        timer_A++;
        timer_B++;
        timer_C++;
        timer_D++;
        
        for (delay_counter = 0; delay_counter < 1000; delay_counter++) {
        }
    }
}