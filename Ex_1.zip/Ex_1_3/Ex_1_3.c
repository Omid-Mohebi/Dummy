#define F_CPU 8000000UL

#include <mega32.h>
#include <delay.h>

#define BTN_UP      PIND.0
#define BTN_DOWN    PIND.1
#define BTN_LEFT    PIND.2
#define BTN_RIGHT   PIND.3
#define BTN_TOGGLE  PIND.4

volatile unsigned long int millis_ticks = 0;
unsigned char led_latched_state[4][8];
unsigned char cursor_row = 0;
unsigned char cursor_col = 0;
unsigned long int last_blink_time = 0;
unsigned char cursor_led_state = 1;

unsigned char current_multiplex_row = 0;
unsigned long int last_multiplex_time = 0;
const unsigned char MULTIPLEX_INTERVAL = 2;

interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
    millis_ticks++;
}

void timer0_init(void)
{
    TCCR0 = (1 << WGM01);
    OCR0 = 124;
    TIMSK |= (1 << OCIE0);
    TCCR0 |= (1 << CS01) | (1 << CS00);
    #asm("sei");
}

void select_led_bar(unsigned char bar)
{
    PORTB = 0x0F;
    if (bar < 4)
    {
        PORTB &= ~(1 << bar);
    }
}

void set_led_data(unsigned char data)
{
    PORTA = data;
}

void handle_button_inputs(void)
{
    unsigned char moved = 0;
    
    if (BTN_TOGGLE == 1)
    {
        delay_ms(50);
        while(BTN_TOGGLE == 1);
        led_latched_state[cursor_row][cursor_col] = !led_latched_state[cursor_row][cursor_col];
    }
    else if (BTN_RIGHT == 1)
    {
        delay_ms(50);
        if (cursor_col < 7) { cursor_col++; moved = 1; }
        while(BTN_RIGHT == 1);
    }
    else if (BTN_LEFT == 1)
    {
        delay_ms(50);
        if (cursor_col > 0) { cursor_col--; moved = 1; }
        while(BTN_LEFT == 1);
    }
    else if (BTN_DOWN == 1)
    {
        delay_ms(50);
        if (cursor_row < 3) { cursor_row++; moved = 1; }
        while(BTN_DOWN == 1);
    }
    else if (BTN_UP == 1)
    {
        delay_ms(50);
        if (cursor_row > 0) { cursor_row--; moved = 1; }
        while(BTN_UP == 1);
    }
    
    if (moved)
    {
        cursor_led_state = 1;
        last_blink_time = millis_ticks;
    }
}

void handle_multiplexed_display(void)
{
    const unsigned int BLINK_INTERVAL = 250;
    unsigned char row_data;
    unsigned char c;
    
    if (millis_ticks - last_multiplex_time >= MULTIPLEX_INTERVAL)
    {
        last_multiplex_time = millis_ticks;
        
        set_led_data(0x00);
        select_led_bar(4);
        
        row_data = 0;
        for (c = 0; c < 8; c++)
        {
            if (led_latched_state[current_multiplex_row][c])
            {
                row_data |= (1 << c);
            }
        }
        
        if (current_multiplex_row == cursor_row)
        {
            if (millis_ticks - last_blink_time >= BLINK_INTERVAL)
            {
                last_blink_time = millis_ticks;
                cursor_led_state = !cursor_led_state;
            }
            
            if (led_latched_state[cursor_row][cursor_col] || cursor_led_state)
            {
                row_data |= (1 << cursor_col);
            }
            else
            {
                row_data &= ~(1 << cursor_col);
            }
        }
        
        set_led_data(row_data);
        select_led_bar(current_multiplex_row);
        
        current_multiplex_row++;
        if (current_multiplex_row >= 4)
        {
            current_multiplex_row = 0;
        }
    }
}

void main(void)
{
    unsigned char i, j;
    
    DDRA = 0xFF;
    DDRB = 0x0F;
    DDRC = 0x00;
    DDRD = 0x00;
    
    PORTA = 0x00;
    PORTB = 0x0F;
    PORTD = 0x00;
    
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            led_latched_state[i][j] = 0;
        }
    }
    
    timer0_init();

    while (1)
    {
        handle_button_inputs();
        handle_multiplexed_display();
    }
}