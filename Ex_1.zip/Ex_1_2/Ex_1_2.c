#define F_CPU 8000000UL

#include <mega32.h>
#include <delay.h>

#define BTN_UP      PIND.0
#define BTN_DOWN    PIND.1
#define BTN_LEFT    PIND.2
#define BTN_RIGHT   PIND.3
#define BTN_TOGGLE  PIND.4

volatile unsigned long int millis_ticks = 0;
unsigned char led_latched_state[3][8];
unsigned char cursor_row = 0;
unsigned char cursor_col = 0;
unsigned long int last_blink_time = 0;
unsigned char cursor_led_state = 1;

interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
    millis_ticks++;
}

void timer0_init(void)
{
    TCCR0 = (1 << WGM01);
    OCR0 = 124;
    TIMSK |= (1 << OCIE0);
    TCCR0 |= (1 << CS01) | (1 << CS00);
    #asm("sei");
}

void set_led(unsigned char row, unsigned char col, unsigned char state)
{
    unsigned char mask = (1 << col);
    switch (row)
    {
        case 0: PORTA = state ? (PORTA | mask) : (PORTA & ~mask); break;
        case 1: PORTB = state ? (PORTB | mask) : (PORTB & ~mask); break;
        case 2: PORTC = state ? (PORTC | mask) : (PORTC & ~mask); break;
    }
}

void handle_button_inputs(void)
{
    unsigned char moved = 0;
    
    if (BTN_TOGGLE == 1)
    {
        delay_ms(50);
        while(BTN_TOGGLE == 1);
        led_latched_state[cursor_row][cursor_col] = !led_latched_state[cursor_row][cursor_col];
    }
    else if (BTN_RIGHT == 1)
    {
        delay_ms(50);
        if (cursor_col < 7) { cursor_col++; moved = 1; }
        while(BTN_RIGHT == 1);
    }
    else if (BTN_LEFT == 1)
    {
        delay_ms(50);
        if (cursor_col > 0) { cursor_col--; moved = 1; }
        while(BTN_LEFT == 1);
    }
    else if (BTN_DOWN == 1)
    {
        delay_ms(50);
        if (cursor_row < 2) { cursor_row++; moved = 1; }
        while(BTN_DOWN == 1);
    }
    else if (BTN_UP == 1)
    {
        delay_ms(50);
        if (cursor_row > 0) { cursor_row--; moved = 1; }
        while(BTN_UP == 1);
    }
    
    if (moved)
    {
        cursor_led_state = 1;
        set_led(cursor_row, cursor_col, 1);
        last_blink_time = millis_ticks;
    }
}

void handle_display_and_blink(void)
{
    unsigned char r, c;
    const unsigned int BLINK_INTERVAL = 250;

    for (r = 0; r < 3; r++)
    {
        for (c = 0; c < 8; c++)
        {
            if (r != cursor_row || c != cursor_col)
            {
                set_led(r, c, led_latched_state[r][c]);
            }
        }
    }
    
    if (millis_ticks - last_blink_time >= BLINK_INTERVAL)
    {
        last_blink_time = millis_ticks;
        cursor_led_state = !cursor_led_state;
    }
    
    if (led_latched_state[cursor_row][cursor_col] || cursor_led_state)
    {
        set_led(cursor_row, cursor_col, 1);
    }
    else
    {
        set_led(cursor_row, cursor_col, 0);
    }
}

void main(void)
{
    DDRA = 0xFF;
    DDRB = 0xFF;
    DDRC = 0xFF;
    DDRD = 0x00;
    
    PORTD = 0x00;
    
    timer0_init();

    while (1)
    {
        handle_button_inputs();
        handle_display_and_blink();
    }
}