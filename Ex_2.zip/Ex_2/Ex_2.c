#define F_CPU 8000000UL

#include <mega32.h>
#include <delay.h>

#define BTN_UP      PINA.2
#define BTN_TOGGLE  PINA.1
#define BTN_DOWN    PINA.0

#define LCD_RS      PORTC.0
#define LCD_RW      PORTC.1
#define LCD_E       PORTC.2
#define LCD_DATA    PORTC

unsigned char led_states[8] = {0,0,0,0,0,0,0,0};
unsigned char current_position = 0;
unsigned char blink_state = 1;
unsigned long int millis_ticks = 0;
unsigned long int last_blink_time = 0;
unsigned long int last_display_update = 0;

interrupt [TIM0_COMP] void timer0_comp_isr(void)
{
    millis_ticks++;
}

void timer0_init(void)
{
    TCCR0 = (1 << WGM01);
    OCR0 = 124;
    TIMSK |= (1 << OCIE0);
    TCCR0 |= (1 << CS01) | (1 << CS00);
    #asm("sei");
}

void lcd_pulse_enable(void)
{
    LCD_E = 1;
    delay_us(1);
    LCD_E = 0;
    delay_us(1);
}

void lcd_write_nibble(unsigned char data)
{
    LCD_DATA = (LCD_DATA & 0x0F) | (data & 0xF0);
    lcd_pulse_enable();
}

void lcd_write_byte(unsigned char data)
{
    lcd_write_nibble(data);
    lcd_write_nibble(data << 4);
    delay_us(50);
}

void lcd_command(unsigned char cmd)
{
    LCD_RS = 0;
    LCD_RW = 0;
    lcd_write_byte(cmd);
    delay_ms(2);
}

void lcd_data(unsigned char data)
{
    LCD_RS = 1;
    LCD_RW = 0;
    lcd_write_byte(data);
    delay_us(50);
}

void lcd_init(void)
{
    delay_ms(20);
    
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_E = 0;
    
    lcd_write_nibble(0x30);
    delay_ms(5);
    lcd_write_nibble(0x30);
    delay_us(150);
    lcd_write_nibble(0x30);
    delay_us(150);
    lcd_write_nibble(0x20);
    delay_us(150);
    
    lcd_command(0x28);
    lcd_command(0x0C);
    lcd_command(0x06);
    lcd_command(0x01);
    delay_ms(2);
}

void lcd_goto(unsigned char row, unsigned char col)
{
    unsigned char address;
    if (row == 0)
        address = 0x80 + col;
    else
        address = 0xC0 + col;
    lcd_command(address);
}

void lcd_puts(char *str)
{
    while (*str)
    {
        lcd_data(*str);
        str++;
    }
}

void lcd_putchar(char c)
{
    lcd_data(c);
}

void update_leds(void)
{
    unsigned char i;
    unsigned char led_output = 0;
    
    for (i = 0; i < 8; i++)
    {
        if (led_states[i])
        {
            led_output |= (1 << i);
        }
    }
    
    if (millis_ticks - last_blink_time >= 150)
    {
        last_blink_time = millis_ticks;
        blink_state = !blink_state;
    }
    
    if (blink_state)
    {
        led_output |= (1 << current_position);
    }
    else if (!led_states[current_position])
    {
        led_output &= ~(1 << current_position);
    }
    
    PORTD = led_output;
}

void update_lcd_display(void)
{
    unsigned char i;
    char pos_str[3];
    
    if (millis_ticks - last_display_update >= 100)
    {
        last_display_update = millis_ticks;
        
        lcd_command(0x01);
        delay_ms(2);
        
        lcd_goto(0, 0);
        lcd_puts("LEDs: ");
        for (i = 0; i < 8; i++)
        {
            if (i == current_position)
            {
                lcd_putchar(blink_state ? (led_states[i] ? '#' : '*') : (led_states[i] ? '#' : '_'));
            }
            else
            {
                lcd_putchar(led_states[i] ? '#' : '-');
            }
        }
        
        lcd_goto(1, 0);
        lcd_puts("Pos:");
        
        pos_str[0] = '0' + current_position;
        pos_str[1] = '\0';
        lcd_puts(pos_str);
        
        lcd_puts(" State:");
        if (led_states[current_position] == 1){
            lcd_puts("ON ");
        }
        else{ 
            lcd_puts("OFF ");
        }
    }
}

void handle_buttons(void)
{
    static unsigned long int last_button_time = 0;
    const unsigned char DEBOUNCE_DELAY = 50;
    
    if (millis_ticks - last_button_time < DEBOUNCE_DELAY)
        return;
    
    if (BTN_UP == 1)
    {
        delay_ms(50);
        while(BTN_UP == 1);
        
        if (current_position < 7)
        {
            current_position++;
        }
        else
        {
            current_position = 0;
        }
        
        blink_state = 1;
        last_blink_time = millis_ticks;
        last_button_time = millis_ticks;
    }
    else if (BTN_DOWN == 1)
    {
        delay_ms(50);
        while(BTN_DOWN == 1);
        
        if (current_position > 0)
        {
            current_position--;
        }
        else
        {
            current_position = 7;
        }
        
        blink_state = 1;
        last_blink_time = millis_ticks;
        last_button_time = millis_ticks;
    }
    else if (BTN_TOGGLE == 1)
    {
        delay_ms(50);
        while(BTN_TOGGLE == 1);
        
        led_states[current_position] = !led_states[current_position];
        last_button_time = millis_ticks;
    }
}

void main(void)
{
    unsigned char i;
    
    DDRA = 0x00;
    DDRB = 0x00;
    DDRC = 0xFF;
    DDRD = 0xFF;
    
    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;
    
    for (i = 0; i < 8; i++)
    {
        led_states[i] = 0;
    }
    current_position = 0;
    
    timer0_init();
    delay_ms(100);
    lcd_init();
    
    lcd_goto(0, 0);
    lcd_puts("LED Controller");
    lcd_goto(1, 0);
    lcd_puts("Ready...");
    delay_ms(300);
    
    while (1)
    {
        handle_buttons();
        update_leds();
        update_lcd_display();
    }
}